<template lang="html">
  <h1>Home</h1>
</template>

<script>
export default {
  name: 'home'
}
</script>

<style lang="css" scoped>
</style>
