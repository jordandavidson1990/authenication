<template lang="html">
  <h1>Login</h1>
</template>

<script>
export default {
  name: 'login'
}
</script>

<style lang="css" scoped>
</style>
